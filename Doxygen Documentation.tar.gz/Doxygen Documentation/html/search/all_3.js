var searchData=
[
  ['peptidtabelle',['Peptidtabelle',['../classPeptidtabelle.html',1,'']]],
  ['proteintabelle',['Proteintabelle',['../classProteintabelle.html',1,'']]]
];
